<div class="leftContent">
    <slot/>
</div>

<style lang="scss">
    .leftContent{
        flex: 1;
        display: flex;
        flex-direction: column;
    }
</style>