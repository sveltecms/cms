<script lang="ts">
    import src from "cms/static/logo.png"
</script>

<img class="logo" {src} alt="svelteCMS">

<style lang="scss">
    .logo{
        width: 90px;
        margin-bottom: 20px;
    }
</style>